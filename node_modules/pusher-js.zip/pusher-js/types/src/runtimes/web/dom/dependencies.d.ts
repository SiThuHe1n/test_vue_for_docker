import { ScriptReceiverFactory } from './script_receiver_factory';
import DependencyLoader from './dependency_loader';
export declare var DependenciesReceivers: ScriptReceiverFactory;
export declare var Dependencies: DependencyLoader;
