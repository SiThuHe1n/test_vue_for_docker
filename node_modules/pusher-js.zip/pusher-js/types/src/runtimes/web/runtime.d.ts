import Browser from './browser';
declare var Runtime: Browser;
export default Runtime;
