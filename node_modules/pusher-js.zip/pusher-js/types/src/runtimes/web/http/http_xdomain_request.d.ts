import RequestHooks from 'core/http/request_hooks';
declare var hooks: RequestHooks;
export default hooks;
