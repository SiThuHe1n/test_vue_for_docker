declare var Isomorphic: any;
export default Isomorphic;
