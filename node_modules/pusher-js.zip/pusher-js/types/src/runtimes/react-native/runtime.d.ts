import Runtime from '../interface';
declare const ReactNative: Runtime;
export default ReactNative;
