interface URLLocation {
    base: string;
    queryString: string;
}
export default URLLocation;
