import { InternalAuthOptions, ChannelAuthorizationHandler } from './options';
declare const ChannelAuthorizer: (authOptions: InternalAuthOptions) => ChannelAuthorizationHandler;
export default ChannelAuthorizer;
