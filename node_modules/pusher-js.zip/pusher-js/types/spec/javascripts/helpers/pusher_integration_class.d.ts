import Pusher from '../../../src/core/pusher';
export default class PusherIntegration extends Pusher {
    static Integration: any;
}
