import Timeline from '../timeline/timeline';

interface TransportConnectionOptions {
  timeline: Timeline;
  activityTimeout: number;
}

export default TransportConnectionOptions;
