interface Callback {
  fn: Function;
  context: any;
}

export default Callback;
