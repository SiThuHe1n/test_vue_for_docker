interface TimedCallback {
  (number?): number | void;
}

export default TimedCallback;
