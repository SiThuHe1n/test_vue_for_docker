interface Window {
  attachEvent: any;
  detachEvent: any;
}
