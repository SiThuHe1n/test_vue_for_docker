interface Window {
  XMLHttpRequest: any;
}
